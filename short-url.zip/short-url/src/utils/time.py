import time


def current_timestamp():
    return int(time.time())
